<?php $__env->startSection('content'); ?>
<h1>Editando Usuario</h1>
<form class="form-horizontal" method="POST" action="<?php echo e(route('users.update', $user->id)); ?>" enctype="multipart/form-data">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label class="control-label col-sm-2" for="nome">Nome</label>
          <div class="col-sm-10">
            <input type="text" name="nome" class="form-control" id="nome" value=<?php echo e($user->nome); ?> />
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2" for="email">Email</label>
          <div class="col-sm-10">
            <input type="email" class="form-control" name="email" value=<?php echo e($user->email); ?> />
            </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2" for="data">Data de Nascimento</label>
          <div class="col-sm-10">
          <input type="date" name="data" class="form-control" id="data" value=<?php echo e($user->datanasc); ?> />
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2" for="foto">Foto</label>
          <div class="col-sm-10">
          <img src="/<?php echo e($user->fotothun); ?>" class="img-thumbnail" alt="<?php echo e($user->nome); ?>"/>
          <input type="file" class="form-control" name="foto" id="foto">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2" for="categoria">Categoria</label>
          <div class="col-sm-10">
          <select name="id_categoria" id="categoria" class="form-control">
          <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          </div>
        </div>
        <div class="form-group"> 
          <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-refresh"></span> Atualizar</button>
          </div>
        </div>
      </form>
<?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>