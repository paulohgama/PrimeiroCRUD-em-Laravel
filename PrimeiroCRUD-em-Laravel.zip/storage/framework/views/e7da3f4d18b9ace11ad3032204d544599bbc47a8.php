

<?php $__env->startSection('content'); ?>
<fieldset class="form-group">
<legend>Deseja deletar?</legend>
  <form method="POST" action="<?php echo e(route('categorias.destroy', $categoria->id)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
        <table>
          <tr>
            <th>Categoria: </th><td><?php echo e($categoria->categoria); ?></td></tr>
        <tr>
        </table>
        <br>
        <div class="btn-group">
            <a  class="btn btn-success" href="<?php echo e(route('categorias.index')); ?>"><span class="glyphicon glyphicon-arrow-left"></span> Cancelar</a>
            <button class="btn btn-danger" type="submit"><span class="glyphicon glyphicon-remove"></span> Deletar</button>
            </div>

    </form>
</fieldset>
<?php if(session('error')): ?>
    <div class="alert alert-danger show" role="alert">
       <?php echo e(session('error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>