<?php $__env->startSection('content'); ?>
<fieldset class="form-group">
<legend>Inserir novo usuario</legend>
<form class="form-horizontal" method="POST" action="<?php echo e(route('users.store')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label class="control-label col-sm-2" for="nome">Nome</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" name="nome" id="nome" placeholder="Nome" value="<?php echo e(old('nome')); ?>"></div></div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="email">Email</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" name="email" id="email" placeholder="E-mail"  value="<?php echo e(old('email')); ?>"></div></div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="foto">Foto</label>
        <div class="col-sm-10">
            <input type="file" class="form-control" name="foto" id="foto"></div></div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="data">Data de Nascimento</label>
        <div class="col-sm-10">
            <input type="date" class="form-control" name="data" id="data" value="<?php echo e(old('data')); ?>"></div></div>
    <div class="form-group">
        <label class="control-label col-sm-2" for="categoria">Categoria</label>
        <div class="col-sm-10">
            <select class="form-control" name="id_categoria" id="categoria">
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->categoria); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select></div></div>
    <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
    <button name="envia"  class="btn btn-info" type="submit"><span class="glyphicon glyphicon-floppy-disk"> Cadastrar</button></div></div>
</form>
<?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>