<?php $__env->startSection('content'); ?>
<br>
<div class="table-responsive">
<table class="table table-bordered">
    <tr align="center">
        <th>ID</th>
        <th>Categoria</th>
        <th colspan="2">Action</th>
    </tr>
    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($categoria->id); ?></td>
            <td><?php echo e($categoria->categoria); ?></td>
            <td><a class="btn btn-info" href="<?php echo e(route('categorias.edit',$categoria->id)); ?>" role="button"><span class="glyphicon glyphicon-edit"> Editar</a></td>
            <td><a class="btn btn-warning" href="<?php echo e(route('categorias.delete',$categoria->id)); ?>" role="button"><span class="glyphicon glyphicon-trash"> Deletar</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  </div>
<?php echo $__env->make('inc.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>