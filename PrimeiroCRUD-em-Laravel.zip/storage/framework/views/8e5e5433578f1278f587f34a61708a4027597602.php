<?php $__env->startSection('content'); ?>
<fieldset class="form-group">
<legend>Cadastrar categoria</legend>
<form class="form-horizontal" method="POST" action="<?php echo e(route('categorias.update', $categoria->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label class="control-label col-sm-2" for="email">Categoria</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="nome" placeholder="Categoria" value=<?php echo e($categoria->categoria); ?>>
        </div>
    </div>
    <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-info">Atualizar</button>
    </div>
  </div>
</form>
</fieldset>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>