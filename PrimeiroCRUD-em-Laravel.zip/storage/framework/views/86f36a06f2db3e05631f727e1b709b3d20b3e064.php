<?php $__env->startSection('content'); ?>
<fieldset class="form-group">
<legend>Deseja deletar?</legend>
  <form method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
        <table>
            <tr>
                <th>Nome: </th>
                <td><?php echo e($user->nome); ?><td><tr>
            <tr>
                <th>Email: </th>
                <td><?php echo e($user->email); ?><td><tr>
        <tr>
            <th>Data de Nascimento: </th>
            <td><input type="date" value="<?php echo e($user->datanasc); ?>" disabled></td></tr>
        <tr>
            <th>Foto: </th>
            <td><img src="<?php echo e($user->fotothun); ?>" class="img-thumbnail" alt="<?php echo e($user->nome); ?>"><img /></td></tr>
        </table>
        </div>
        <br>
        <div class="btn-group"> 
        <button class="btn btn-danger" type="submit"></span>Deletar</button>
        <a  class="btn btn-success" href="<?php echo e(route('users.index')); ?>" role="button">Cancelar</a>
    </div>
    </form>
</fieldset>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>