<?php $__env->startSection('content'); ?>

<?php if(session('dawn')): ?>
    <div class="alert alert-danger" role="alert">
  <strong>Oh Droga!!</strong> Não foi possivel enviar o email; 
</div>
<?php endif; ?>
<div class="table-responsive">
<table class="table table-bordered">
    <tr align="center">
        <td>ID</td>
        <td>Nome</td>
        <td>E-mail</td>
        <td>Data de Nascimento</td>
        <td>Foto</td>
        <td>Categoria</td>
        <td colspan="2">Ação</td>
    </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->nome); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->datanasc); ?></td>
            <td><img src="<?php echo e($user->fotothun); ?>" class="img-thumbnail" alt="<?php echo e($user->nome); ?>"><img /></td>
            <td><?php echo e($user->categoria); ?></td>
            <td><a class="btn btn-info" href="<?php echo e(route('users.edit',$user->id)); ?>" role="button"><span class="glyphicon glyphicon-edit"> Editar</a></td>
            <td><a class="btn btn-warning" href="<?php echo e(route('users.delete',$user->id)); ?>" role="button"><span class="glyphicon glyphicon-trash"> Deletar</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>