

<?php $__env->startSection('content'); ?>
<fieldset class="form-group">
<legend>Cadastrar categoria</legend>
<form class="form-horizontal" method="POST" action="<?php echo e(route('categorias.update', $categoria->id)); ?>"/>
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label class="control-label col-sm-2" for="nome">Categoria</label>
        <div class="col-sm-10">
            <input type="text" maxlength="100" required class="form-control" id="nome" name="nome" placeholder="Categoria" value=<?php echo e($categoria->categoria); ?>>
        </div>
    </div>
    <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-refresh"></span> Atualizar</button>
    </div>
  </div>
</form>
</fieldset>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>