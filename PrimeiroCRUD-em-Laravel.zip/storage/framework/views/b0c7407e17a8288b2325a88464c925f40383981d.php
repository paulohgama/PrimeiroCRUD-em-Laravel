<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(session('success')); ?></strong>
    </div>
<?php endif; ?>

<?php if(session('failure')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong><?php echo e(session('failure')); ?></strong>
    </div>
<?php endif; ?>