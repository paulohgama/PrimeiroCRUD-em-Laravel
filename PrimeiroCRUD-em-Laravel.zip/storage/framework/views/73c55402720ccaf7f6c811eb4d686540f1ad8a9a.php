<?php $__env->startSection('content'); ?>
<fieldset class="form-group">
<legend>Cadastrar categoria</legend>
<form class="form-horizontal" method="POST" action="<?php echo e(route('categorias.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label class="control-label col-sm-1" for="nome">Nome</label>
        <div class="col-sm-10">
            <input type="text" name="nome" class="form-control" id="nome" placeholder="Categoria" value="<?php echo e(old('nome')); ?>">
        </div>
    </div>
    <div class="form-group"> 
    <div class="col-sm-offset-1 col-sm-10">
      <button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-floppy-disk"> Cadastrar</span></button>
    </div>
  </div>
</form>
</fieldset>
<?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>